#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>
#include <time.h>
#include <bits/getopt_core.h>
#include <stdbool.h>

pthread_t *prisoner;
pthread_t *prisoner_smart;
pthread_mutex_t global_lock;
pthread_mutex_t box_lock[100];
int boxes[100];
int s; 
bool found[100];
bool found_smart[100];
int win_counter = 0;
int win_counter_smart = 0;
int win_counter_draw = 0;
int win_counter_draw_smart = 0;
int prisoner_no_smart_arr[100];


void swap(int *a,int *b){
    int temp = *a;
    *a = *b;
    *b = temp; 
}

void random_box(int arr[], int n){
    for(int i = n - 1; i >= 0; i-- ){
        int j = rand() % (i + 1);
        swap(&arr[i], &arr[j]);
    }
}

void* search_box_random(void* search){

        int *i = (int*)search;
        pthread_mutex_lock(&global_lock);
        for (int j = 0; j < 50; j++)
        {
            if (*i == boxes[rand() % 100])
            {
                found[*i] = true;
            }
        }
        pthread_mutex_unlock(&global_lock);
}

void* search_box_smart(void* search){

        int *i = (int*)search;
        pthread_mutex_lock(&global_lock);
        int box_reference = *i;
        
        for(int j = 0; j < 50; j++)
        {
            if (*i == boxes[box_reference]){
                found_smart[box_reference] = true;
                break;
            }
            box_reference = boxes[box_reference];
        }
        pthread_mutex_unlock(&global_lock);
}

void* random_drawer(void* search){
    int *i = (int*)search;
    
    int selected = *i;
    for (int j = 0; j < 50; j++)
    {
        
        pthread_mutex_lock(&box_lock[selected]);
        if (*i == boxes[selected])
        {
            found[*i] = true;
            break;
        }
        selected = rand() % 100;
    }
    pthread_mutex_unlock(&box_lock[selected]);
}
void* smart_global(void* search){

}
void* smart_drawer(void* search){

}

//int run_threads(void* (*f)(void*)){
//    random_box(boxes, 100);
//    for (int i = 0; i < 100; i++)
//    {
//        int th = pthread_create(&prisoner[i], NULL, f, boxes);
//        if (th){
//            printf("error");
//            return 1;
//        }
//    }
//    for(int j= 0; j < 100; j++){
//        pthread_join(prisoner[j], NULL);
//    }
//    free(prisoner);
//}

//

int main(int argc, char **argv){

    prisoner = malloc(100 * sizeof(pthread_t));
    prisoner_smart = malloc(100 * sizeof(pthread_t));
    int opt;
    int games = 100;
    s = time(NULL); 
    srand(s);

    



    while((opt = getopt(argc, argv, "sn:")) != -1){

        switch(opt){
            case 's':
                //s = atoi(optarg);
            break;

            case 'n':
                games = atoi(optarg);
            break;
        }
    }

    

    for (int i = 0; i < games; i++)
    {
        for(int i = 0; i < 100; i++){
            boxes[i] = i;
            found[i] = false;
            found_smart[i] = false;
        }

        random_box(boxes, 100);

        for (int k = 0; k < 100; k++)
        {   
            int prisoner_no = k;
            pthread_create(&prisoner[k], NULL, search_box_random, (void*)&prisoner_no);
        }
        for (int j = 0; j < 100; j++)
        {
            pthread_join(prisoner[j], NULL);
        }
        for (int a = 0; a < 100; a++)
        {
            if (found[a] == false)
            {
                win_counter--;
                break;
            }
        }
        win_counter++;

        for (int k = 0; k < 100; k++)
        {
            prisoner_no_smart_arr[k] = k;
            pthread_create(&prisoner_smart[k],NULL, search_box_smart, (void*)&prisoner_no_smart_arr[k]);
        }
        for (int j = 0; j < 100; j++)
        {
            pthread_join(prisoner_smart[j], NULL);
        }

        for (int a = 0; a < 100; a++)
        {
            if (found_smart[a] == false)
            {   
                win_counter_smart--;
                break;
            }
        }
        win_counter_smart++;
        
    }
    free(prisoner);
    free(prisoner_smart);
    
    printf("random global %d/%d wins/games = %0.2f %%\n", win_counter,games, (double)100 * ((double)win_counter /(double) games));
    printf("smart global %d/%d wins/games = %0.2f %%\n", win_counter_smart,games, (double)100 * ((double)win_counter_smart / (double)games));
    return 0;
}