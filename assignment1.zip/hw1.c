#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>



int main(int argc, char** argv)
{
	//a) if no argument is given prints the enviornment directly
		
	int opt;
	int error_trace = 0;
	char *remove = NULL;
	int other_counter = 0;
	
	//declared the variables that will track -v and -u and the counter which will help make sure the arguments are correct
	
	while ((opt = getopt(argc, argv, "vu:")) != -1){
		
		switch(opt){
		
		case 'v':
			error_trace = 1;
			other_counter++;
			break;
			
		case 'u':
			remove = optarg;
			other_counter += 2;
			break;
		
		default:
			fprintf (stderr, "%s\n [-v] [-u name]\n", argv[0]);
			return 1;
		}
	}		
	
	if (remove != NULL){
		if (error_trace != 0){
			fprintf(stderr, "Deleting variable from enviornment\n");
		}
		unsetenv(remove);
	}
	
	
	extern char** environ;

	if(argc <= 1){
		for (char **env = environ; *env != NULL; env++){
			printf ("%s\n", *env);
			if (error_trace != 0){
				fprintf(stderr, "Prints enviornment if no argument or optional argument is given\n");
			}
		}
	}
	
	
	//b) if the argument given is in the form NAME=VALUE puts it in the enviornemnt
	
	else {
	
	char *buffer[argc];
	
	int buffer_counter = 0;
	
		for(int i = 1; i < argc; i++){
			char *equal = strchr(argv[i], '=');
			if (equal != NULL){
				
				char *name = strtok(argv[i], "=");
				char *value = strtok(NULL, "=");
				other_counter++;
				
				if (setenv(name, value, 1) != 0){
					perror("setenv died");
				}
			}

		}
		
		int b = other_counter + 1;
		for(;b < argc; b++){
			buffer[buffer_counter] = argv[b];
			printf("argv elements %s\n", argv[b]);
			buffer_counter++;			
		}
		
		buffer[buffer_counter] = NULL;
		

		printf("buffer counter %d\n", buffer_counter);
		printf("other counter %d\n", other_counter);
		printf("argc %d\n", argc);
		
		for (int k = 0; k < buffer_counter; k++){
			printf("%s\n", buffer[k]);
		}
		
		if (buffer_counter < 1){
		
			for (char **env = environ; *env != NULL; env++){
				printf ("%s\n", *env);	
			}
		}
		else{
			if (error_trace != 0){
				fprintf(stderr, "command executed\n");
			}
		
			execvp(buffer[0], buffer);
			perror ("error executing");
		}
	}
	
	//This checks for a '=' and if it finds them it considers them name=value pairs
	//the other counter, counts functions we declared like -u -v and name=value pairs
	//whatever is left not counted by the other counter should be commands 
	
	return 0;
}

















