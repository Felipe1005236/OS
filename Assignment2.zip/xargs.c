#include <stdio.h> 
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(int argc,char** argv) {

    int opt; 
    int error_trace = 0;
    int max_input = 0;
    int limit = 0;

    char *line = NULL;
    ssize_t read;
    size_t len;
    int counter = 1;
    int pid;
    int status;
    int processes = 1;
    int process_counter = 0;


    while ((opt = getopt(argc, argv, "tj:n:")) != -1){

        switch(opt){
            case 'n':
                limit = atoi(optarg);
                break;
            case 't':
                error_trace = 1;
                break;
            case 'j':
                processes = atoi(optarg);
                if(processes == 0){
                    fprintf(stderr, "Invalid Argument");
                }
                break;

            default:
			    fprintf (stderr, "%s\n [-v] [-u name]\n why", argv[0]);
			    return 1;
        }
    }
    //Declared the cases with the necesary arguments and flags
    
    char *arguments[2048];

    //Declared the arguments vector to be of the size of the real xargs meaning 2048 bytes
    
    if(optind == argc){
        arguments[0] = "echo";
    }
    else{
        arguments[0] = argv[optind];
    }

    //Ifa command was given then it puts it as the first element else it echos

    pid_t children[processes];

    while(((read = getline(&line, &len, stdin)) != -1)){

        char *token = strtok(line, " \t\n");

        while(token != NULL){

            arguments[counter] = (char*) malloc(strlen(token));

            strcpy(arguments[counter], token);

            counter++;

    //Gets the input from stdin and copies them approprietly

            if (counter == limit + 1){
                arguments[counter+1] = NULL;

                if(error_trace != 0){
                    for(int j = 0; j < limit + 1; j++){
                        fprintf(stderr, "%s ", arguments[j]);
                    }
                    fprintf(stderr, "\n");
                }

    //checks for error tracing and what the delimiter of n could be

                children[process_counter] = fork();

                if(children[process_counter] == 0){
                    execvp(arguments[0], arguments);
                    perror("Execvp died");
                }
                else if(children[process_counter] == -1){
                    fprintf(stderr, "fork failed\n");
                }
                process_counter++;

    //it forks and waits for however many concurrent  processes you declared with j

                if(process_counter == processes){

                    for(int i = 0; i < processes; i++){
                        pid = children[i];
                        if(pid > 0){
                            int wait_pid = waitpid(pid, &status, 0);
                            if(wait_pid == -1){
                                perror("waitpid died");
                            }
                        }
                    }

    //waits for the amount of processes before waiting

                    process_counter = 0;
                }

                for(int j = 1; j < limit + 1; j++){
                    free(arguments[j]);
                }

    //frees the allocated memory

                counter = 1;
            }
        

            token = strtok(NULL, " \t\n");
        }
    }
    
    if(counter > 0){
        arguments[counter] = NULL;
        printf("why here though");
        if(error_trace != 0){
            for(char** i = arguments; *i != NULL; i++){
                fprintf(stderr, "%s ", *i);
            }
            fprintf(stderr, "\n");
        }
        execvp(arguments[0], arguments);
    }
    //corner case executes the whole stdin if no limit was given

return 0;
}

