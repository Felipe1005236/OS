#include <cjson/cJSON.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/wait.h>
#include "parse.c"
#include "fetch.c"

int play(question_t *quiz){
    int points = 8;
    int attempts = 3;

    char *url = "https://opentdb.com/api.php?amount=1&category=18&type=multiple";

    char *result = fetch(url);

    if(result == NULL){
        printf("fetch died");
        return EXIT_FAILURE;
    }

    if(parse(quiz, result) == -1){
        printf("parse died");
        return EXIT_FAILURE;
    }

    printf("\n%s\n", quiz->question_text);

    quiz = quiz->next;

    const char answers[4] = {'a', 'b', 'c', 'd'};

    char correct = ' ';

    
    
}