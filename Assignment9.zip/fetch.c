#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/wait.h>

char* fetch(char *url){

    int pfd[2];
    pid_t pid;

    if (pipe(pfd) == -1){
        perror("pipe");
        exit(1);
    }

    pid = fork();
    if(pid == -1){
        perror("fork");
        exit(1);
    }

    // Forks to create both ends of the pipe

    if(pid == 0){
        close(pfd[0]);

        int dup = dup2(pfd[1], STDOUT_FILENO);

        if (dup == -1)
        {
            perror("duplicate");
            exit(1);
        }
        close(pfd[1]);

        char* args[] = {"curl", "-s", url, NULL};

        execvp(args[0], args);

        perror("execvp");
        exit(0);
    }

    // Makes the child process the write end of the pipe and executes curl to fetch

    else{
        close(pfd[1]);
        char* result = NULL;

        size_t size = 0;
        ssize_t content = 0;
        char buffer[1024];

        //creates a buffer and sizes for the read content
        content = read(pfd[0], buffer, sizeof(buffer));

        while((content) > 0){
            
            printf("%s", buffer);

            char* temp = (char*)realloc(result, size + content + 1);
            if(temp == NULL){
                perror("realloc");
                free(result);
                close(*pfd);
                return NULL;
            }

            result = temp;

            memcpy(result + size, buffer, content);
            size += content;
        }

        //Parent of the process is the read end of the pipe and gets all values from the JSON file

        close(*pfd);
        waitpid(-1, NULL, 0);

        //closes the pipe

        if(result != NULL){
            result[size] = '\0';
        }

        printf("%s \n", result);

        return result;
    }
}

int main(){
    char* url = "https://opentdb.com/api.php?amount=1&category=18&type=multiple";

    char *resut = fetch(url);

    printf("%s", resut);
}

// When running sometimes you get an empty array but that happens from the websites side not the code :/

