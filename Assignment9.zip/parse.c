#include <jansson.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/wait.h>
#include "fetch.c"


typedef struct question{
    char *question_text;
    char *answers[4];
    int correct_idx;
    struct question *next;
}question_t;

typedef struct{
    question_t *front;
    question_t *back;
}quiz_t;

void add(quiz_t *quiz, const char *question_text,char *choices[], const char *correct){

    question_t *new = malloc(sizeof(question_t));

    if(new == NULL){
        perror("Malloc new");
        return;
    }

    new->question_text = strdup(question_text);
    new->correct_idx = atoi(strdup(correct));
    new->next = NULL;

    for (int i = 0; i < 4; i++)
    {
        new->answers[i] = choices[i] ? strdup(choices[i]) : NULL;
    }
    

    if(quiz->front == NULL){
        quiz->front = new;
        quiz->back = new;
    }
    else{
        quiz->back->next = new;
        quiz->back = new;
    }
    
}

int parse(quiz_t *quiz, const char *msg){

    json_t *root;
    json_error_t error;

    root = json_loads(msg,0, &error);

    if(!root){
        fprintf(stderr, "JSON died : %d %s\n ", error.line, error.text);
        return -1;
    }

    json_t *question = json_object_get(root, "question");

    if(!json_is_string(question)){
        perror("error question");
        return EXIT_FAILURE;
    }

    json_t *choices = json_object_get(root, "choices");

    if(!json_is_array(choices) || json_array_size(choices) > 4){
        fprintf(stderr, "Error");
        return -1;
    }

    char *choices_full[4] = {NULL};

    for (int i = 0; i < json_array_size(choices); i++)
    {
        json_t *ans = json_array_get(choices, i);
        if (json_is_string(ans))
        {
            choices_full[i] = (char*) json_string_value(ans);
        }
        else perror("error"); return -1;
    }

    json_t *correct = json_object_get(root, "correct choice");

    if(!json_is_integer(correct)){
        perror("Format");
    }

    int correct_int = json_integer_value(correct);

    if(correct_int < 0 || correct_int >= json_array_size(choices)){
        perror("Invalid index");
        return EXIT_FAILURE;
    }

    add(quiz, question, choices, correct);
    
}

int main(){

    char *url = "https://opentdb.com/api.php?amount=1&category=18&type=multiple";

    char *result = fetch(url);

    //printf("%s\n", result);

    quiz_t *quiz = parse(quiz, result);
}