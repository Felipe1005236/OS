#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>

enum state_machine {SPACE, WORD};

void count (int *line, int *word, size_t size, char *text){
    int state = SPACE;

    for (int i = 0; i < size; i++)
    {
        if(text[i] == '\n'){
            (*line)++;
            state = SPACE;
        }
        if(isspace(text[i])){
            state = SPACE;
        }
        else if(state == SPACE){
            state = WORD;
            (*word)++;
        }
    }
}

//Utilizes a state machine to check the state of the counter

void check_error(bool check, const char* error){
    if (check)
    {
        perror(error);
        exit (1);
    }
}

//General error check to throw errors

int main(int argc, char* argv[]){

    int line = 0; 
    int word = 0;
    size_t size;

    if(argc >= 2){

        for (int i = 1; i < argc; i++)
        {
            line = 0;
            word = 0;
            const char* path = argv[i];

            int fd = open(path, O_RDONLY);
            check_error((fd < 0), "error open failed");

            struct stat stat_buffer;
            check_error(fstat(fd, &stat_buffer), "error fstat failed");

            //Opens the file as a read only file and initialized a stat struct for fstat.

            if (!S_ISREG(stat_buffer.st_mode))
            {
                close(fd);

                FILE *std_IO = fopen(argv[i], "r");
                check_error(std_IO == NULL, "error fopen failed");

                size = stat_buffer.st_size;

                char buffer[size + 1];

                int read = fread(buffer, sizeof(char), size, std_IO);
                check_error(read < 0, "error fread failed");

                count(&line, &word, size, buffer);

                fclose(std_IO);

            //checks for irregular files

            }
            else{
                size = stat_buffer.st_size;

                char *file = mmap(NULL, size, PROT_READ, MAP_PRIVATE, fd, 0);
                count(&line, &word, size, file);

                check_error(file == MAP_FAILED, "error mmap failed");
            }

            //If it is a regular file then it counts the things regularly 

            printf("%d %d %lu %s\n", line, word, size, argv[i]);   
        }
    }
    else{
        
        fseek(stdin, 0, SEEK_END);
        size = ftell(stdin);
        fseek(stdin, 0, SEEK_SET);

        char buffer[size + 1];

        int file = fread(buffer, sizeof(char), size, stdin);
        check_error(file < 0, "error fread failed");

        count(&line, &word, size, buffer);

        printf("%d %d %lu\n", line, word, size);

        //Last check for safekeeping.
    }
}