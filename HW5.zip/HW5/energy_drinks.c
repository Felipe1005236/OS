#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>
#include <bits/getopt_core.h>

int payment_counter = 0;
int supply = 0;
int coin = 0;
int machine_capacity = 4;
int number_students = 2;
int price = 5;

pthread_cond_t check_supply;
pthread_cond_t machine_empty;
pthread_mutex_t availability;

pthread_t supplier_thread;
pthread_t machine_thread;


void *supplier(void *su);

void load_drink(){
    pthread_mutex_lock(&availability);
    while(supply == 0){
        pthread_cond_signal(&check_supply);
        printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
        printf("supplier loading the machine\n");
        supply = machine_capacity;
        printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
        printf("%d coins\n", coin);
        coin = 0;
    }
    pthread_mutex_unlock(&availability);
}

//Load drink sends a signal to check supply when the availability can be unlocked

void dispense_drink(){
    if (payment_counter == price){
        supply--;
        coin += payment_counter;
        payment_counter = 0;
    }
}

//dispenses the drinks

void insert_coin(void* s_id){
    int id = *(int*)s_id;
    pthread_mutex_lock(&availability);
    while(supply == 0){
        pthread_cond_wait(&check_supply, &availability);
        printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
        printf("student waiting for machine to be refilled\n");
    }
    for (int i = 0; i < price; i++)
    {
        printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
        printf("%d coins inserted by student %d\n", payment_counter, id);
        payment_counter++;
    }
}

//Insert coin locks the availability 

void pickup_drink(void* s_id){
    int id = *(int*)s_id;
    printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
    printf("student %d enjoying drink\n", id);
    pthread_mutex_unlock(&availability);
}

//pickup drink unlocks the availability to let other students get their drinks

void *machine(void *m){
    while (1)
    {
        if (supply != 0){
            pthread_cond_signal(&check_supply);
            dispense_drink();
            }  
    }   
}

//machine has a not used in variable in its declaration since the pthread_create sintax asks for it

void *student(void *s_id){
    insert_coin(s_id);
    pickup_drink(s_id);
}

void *supplier(void *su){
    while(1){
        load_drink();
    }
}

int main(int argc, char **argv){

    int opt;
    if(pthread_cond_init(&check_supply, NULL) != 0){
        perror("conditional vairable failed");
        exit(1);
    }

    while ((opt = getopt(argc, argv, "n:c:p:")) != -1){

        switch(opt){

            case 'n':
                number_students = atoi(optarg);
            break;

            case 'c':
                machine_capacity = atoi(optarg);
            break;

            case 'p':
                price = atoi(optarg);
            break;
        }
    }

    int student_ids[number_students];
    pthread_t student_thread[number_students]; 

    pthread_create(&machine_thread, NULL, machine, NULL);
    printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
    printf("machine established\n");

    pthread_create(&supplier_thread, NULL, supplier, NULL);
    printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
    printf("supplier established\n");

    for(int i = 0; i < number_students; i++){
        student_ids[i] = i;
        pthread_create(&student_thread[i], NULL, student, &student_ids[i]);
        printf("[%d/%d drinks, %d coins, %d inserted]", supply, machine_capacity, coin, payment_counter);
        printf("student %ls established\n", &student_ids[i]);
    }

    for (int i = 0; i < number_students; i++)
    {
        pthread_join(student_thread[i], NULL);
    }

    //creates all threads and since student is the only multiple threaded process of the same kind it is also joined. 
} 