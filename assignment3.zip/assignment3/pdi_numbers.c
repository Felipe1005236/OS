#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <math.h>
#include <pthread.h>

struct thread_range{
    int low_lim;
    int up_lim;
};

int check_pdi(int n){

    if (n < 10){
        return 1;
        //trivially a pdi
    }
    int digits[10];
    int digits_amount = 0;
    int temp = n;
    int max = 0;

    while(temp > 0){
        digits[digits_amount] = temp % 10;
        if(digits[digits_amount] > max){
            max = digits[digits_amount];
        }
        temp /= 10;
        digits_amount++;
    }
    if(max < 2){
        return 0;
        //not an pdi
    }

    for(int i = 0; i <= (log(n) / log(max)); i++){
        int sum = 0;
        for (int j = 0; j < digits_amount; j++)
        {
            sum += pow(digits[j], i);
        }
        if (sum == n){
            return 1;
        }
    }
    return 0;
}

void* apply_to_range(void* r){
    struct thread_range* range = (struct thread_range*) r;

    for(int i = range->low_lim; i < range->up_lim; i++){
        if (check_pdi(i) == 1) printf("%d\n", i); 
    }
}

int main(int argc, char** argv){
    int n;
    int opt;
    int lower_limit = 1;
    int upper_limit = 10000;
    int error_trace = 0;
    struct thread_range thread_arg;
    int thread_counter = 1;


    while((opt = getopt(argc, argv, "s:e:t:v")) != -1){

        switch(opt){
                case 's':
                    lower_limit = atoi(optarg);
                    break;
                case 'e':
                    upper_limit = atoi(optarg);
                    break;
                case 't':
                    thread_counter = atoi(optarg);
                    break;
                case 'v':
                    error_trace = 1;
                    break;
                default:
	    		    fprintf (stderr, "%s\n [-v] [-u name]\n why", argv[0]);
	    		    return 1;
        }

    }
        thread_arg.low_lim = lower_limit;
        thread_arg.up_lim = upper_limit;

        if (thread_counter > 1){
            pthread_t *thread = malloc(thread_counter * sizeof(pthread_t));
            int list[thread_counter][2];
            int difference = (upper_limit - lower_limit)/thread_counter;

            list[0][0] = lower_limit;
            list[0][1] = lower_limit + difference;
            for(int i=1; i < thread_counter; i++){
                list[i][0] = list[i - 1][1] + 1;
                list[i][1] = list[i][0] + difference;
            }

            for (int i = 0; i < thread_counter; i++)
            {
                struct thread_range *arguments = malloc(sizeof(struct thread_range));
                arguments->low_lim = list[i][0];
                arguments->up_lim = (i == thread_counter - 1) ? upper_limit : arguments->low_lim + difference;

                if(error_trace != 0){
                    fprintf(stderr,"thread,%d searching[%d, %d]\n", i, arguments->low_lim, arguments->up_lim);
                }
                int pr = pthread_create(&thread[i], NULL, apply_to_range, arguments);

                if(pr){
                    printf("error");
                    return 1;
                }
            }
            //goes through the threads and separates the processes
            for (int i = 0; i < thread_counter; i++)
            {
                pthread_join(thread[i], NULL);
            }
            if(error_trace != 0){
                for (int i = 0; i < thread_counter; i++)
                {
                    fprintf(stderr, "Finished Searching threads %d \n", i);
                }
            }
            free(thread);
   
        }

        else{
            apply_to_range(&thread_arg);
        }
        //if the threads is just one it does it singularly.
    return 0;
}